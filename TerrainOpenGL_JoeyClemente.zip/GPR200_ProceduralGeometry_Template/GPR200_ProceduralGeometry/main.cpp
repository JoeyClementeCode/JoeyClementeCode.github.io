// By. Joey Clemente

#include "GL/glew.h"
#include "GLFW/glfw3.h"

#include <glm/glm.hpp>
#include <glm/matrix.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <stdio.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "imgui/imgui.h"
#include "imgui/imgui_impl_glfw.h"
#include "imgui/imgui_impl_opengl3.h"

#include "EW/Shader.h"
#include "EW/EwMath.h"
#include "EW/Camera.h"
#include "EW/Mesh.h"
#include "EW/Transform.h"
#include "ShapeGen.h"

using namespace glm;

void processInput(GLFWwindow* window);
void resizeFrameBufferCallback(GLFWwindow* window, int width, int height);
void keyboardCallback(GLFWwindow* window, int keycode, int scancode, int action, int mods);
float randomRange(float min, float max);
void mouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void mousePosCallback(GLFWwindow* window, double xpos, double ypos);
void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods);

float lastFrameTime;
float deltaTime;

int SCREEN_WIDTH = 1080;
int SCREEN_HEIGHT = 640;

float moveSpeed = 1.0f;
float rotateSpeed = 3.0f;
float scaleSpeed = 1.0f;

double prevMouseX;
double prevMouseY;
bool firstMouseInput = false;
const float MOUSE_SENSITIVITY = 0.1f;

Camera camera((float)SCREEN_WIDTH / (float)SCREEN_HEIGHT);

Transform cubeTransform, planeTransform, sphereTransform, coneTransform, waterTransform, lightTransform;

vec3 bgColor = vec3(0);
vec3 lightColor = vec3(1.0f);
vec3 objectColor = vec3(1.0f);
vec3 waterColor = vec3(0, 0, 1.0f);
vec3 lightOrbitCenter = vec3(0, 3.0f, 0);
float frequency = 1.0f;
float amplitude = 1.0f;
int octaves = 1;
float persistence = 2.0f;
float lacunarity = 2.0f;
float lightOrbitRadius = 5.0f;
float lightOrbitSpeed = 1.0f;
float ambientStrength = 0.3f;
float specularStrength = 0.0f;
float diffuseStrength = 0.7f;
int shine = 16;

vec3 colZero = vec3(1, 1, 1), colOne =  vec3(.7,.7,.7), colTwo = vec3(.2, .6, .3), colThree = vec3(0, 1, 0), colFour = vec3(.5, .2, .4), colFive = vec3(0, 0, 1);

bool cullingEnabled = true;
bool drawAsPoints = false; 

GLuint loadTexture(const char* filePath);

int main() {
	if (!glfwInit()) {
		printf("glfw failed to init");
		return 1;
	}

	GLFWwindow* window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Procedural Geometry", 0, 0);
	glfwMakeContextCurrent(window);

	if (glewInit() != GLEW_OK) {
		printf("glew failed to init");
		return 1;
	}

	glfwSetFramebufferSizeCallback(window, resizeFrameBufferCallback);
	glfwSetKeyCallback(window, keyboardCallback);
	glfwSetScrollCallback(window, mouseScrollCallback);
	glfwSetCursorPosCallback(window, mousePosCallback);
	glfwSetMouseButtonCallback(window, mouseButtonCallback);

	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);

	// Setup UI Platform/Renderer backends
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init();

	//Dark UI theme.
	ImGui::StyleColorsDark();

	Shader shader("shaders/vertexShader.vert", "shaders/fragmentShader.frag");
	Shader unlitShader("shaders/defaultLit.vert", "shaders/unlit.frag");
	Shader waterShader("shaders/waterShader.vert", "shaders/waterFrag.frag");

	MeshData cubeMeshData, planeMeshData, sphereMeshData, coneMeshData, planeMeshData2;
	createPlane(50.0f, 50.0f, 50.0f, objectColor, planeMeshData); // Terrain
	createPlane(50.0f, 50.0f, 50.0f, waterColor, planeMeshData2); // Water
	createSphere(2, 6, objectColor, sphereMeshData); // Light

	Mesh planeMesh(&planeMeshData);
	Mesh waterMesh(&planeMeshData2);
	Mesh sphereMesh(&sphereMeshData);

	GLuint perlin = loadTexture("textures/perlin.jpg");

	//Enable back-face culling
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);

	//Enable blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	glPointSize(3.0f);

	planeTransform.position = vec3(0.0f, 0.5f, 0.0f);
	waterTransform.position = vec3(0.0f, 1.15f, 0.0f);
	sphereTransform.position = vec3(25.0f, 10.0f, -25.0f);
	lightTransform.scale = vec3(0.5f);
	lightTransform.position = vec3(25.0f, 10.0f, -25.0f);

	while (!glfwWindowShouldClose(window)) {
		processInput(window);
		glClearColor(0.1f, 0.15f, 0.2f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		ImGui_ImplOpenGL3_NewFrame();
		ImGui_ImplGlfw_NewFrame();
		ImGui::NewFrame();

		float time = (float)glfwGetTime();
		deltaTime = time - lastFrameTime;
		lastFrameTime = time;

		shader.use();
		shader.setMat4("Projection", camera.getProjectionMatrix());
		shader.setMat4("View", camera.getViewMatrix());

		shader.setVec3("uLightColor", lightColor);
		shader.setVec3("uObjectColor", objectColor);
		shader.setVec3("uLightPos", lightTransform.position);
		shader.setVec3("uEyePos", camera.position);
		shader.setFloat("uAmbientStrength", ambientStrength);
		shader.setFloat("uSpecularStrength", specularStrength);
		shader.setFloat("uDiffuseStrength", diffuseStrength);
		shader.setInt("uShininess", shine);
		shader.setInt("noise", 0);
		shader.setFloat("frequency", frequency);
		shader.setFloat("amplitude", amplitude);
		shader.setInt("octaves", octaves);
		shader.setFloat("persistence", persistence);
		shader.setFloat("lacunarity", lacunarity);
		shader.setVec3("colZero", colZero);
		shader.setVec3("colOne", colOne);
		shader.setVec3("colTwo", colTwo);
		shader.setVec3("colThree", colThree);
		shader.setVec3("colFour", colFour);
		shader.setVec3("colFive", colFive);

		shader.setMat4("Model", planeTransform.getModelMatrix());
		planeMesh.draw(drawAsPoints);

		unlitShader.use();
		unlitShader.setMat4("uProjection", camera.getProjectionMatrix());
		unlitShader.setMat4("uView", camera.getViewMatrix());
		unlitShader.setMat4("uModel", lightTransform.getModelMatrix());
		unlitShader.setVec3("uColor", lightColor);
		sphereMesh.draw(drawAsPoints);

		waterShader.use();
		waterShader.setMat4("uProjection", camera.getProjectionMatrix());
		waterShader.setMat4("uView", camera.getViewMatrix());
		waterShader.setMat4("uModel", waterTransform.getModelMatrix());
		waterShader.setInt("noise", 0);
		waterShader.setFloat("iTime", time);
		waterShader.setVec3("planeColor", waterColor);
		waterShader.setVec3("uLightColor", lightColor);
		waterShader.setVec3("uObjectColor", objectColor);
		waterShader.setVec3("uLightPos", lightTransform.position);
		waterShader.setVec3("uEyePos", camera.position);
		waterShader.setFloat("uAmbientStrength", ambientStrength);
		waterShader.setFloat("uSpecularStrength", specularStrength);
		waterShader.setFloat("uDiffuseStrength", diffuseStrength);
		waterShader.setInt("uShininess", shine);
		waterMesh.draw(drawAsPoints);


		ImGui::Begin("Settings");

		ImGui::SliderFloat("Frequency", &frequency, 0.9f, 1.1f);
		ImGui::SliderFloat("Amplitude", &amplitude, 0.1f, 3.0f);
		ImGui::SliderInt("Octaves", &octaves, 1, 4);
		ImGui::SliderFloat("Persistence", &persistence, 0.1f, 3.0f);
		ImGui::SliderFloat("Lacunarity", &lacunarity, 0.1f, 3.0f);
		ImGui::SliderFloat("AmbientK", &ambientStrength, 0.0f, 1.0f);
		ImGui::SliderFloat("DiffuseK", &diffuseStrength, 0.0f, 1.0f);
		ImGui::SliderFloat("SpecularK", &specularStrength, 0.0f, 1.0f);
		ImGui::SliderInt("Shininess", &shine, 1, 256);
		ImGui::ColorEdit3("Light Color", &lightColor.r);
		ImGui::ColorEdit3("Object Color", &objectColor.r);
		ImGui::ColorEdit3("Peak Color", &colZero.r);
		ImGui::ColorEdit3("Rocky Color", &colOne.r);
		ImGui::ColorEdit3("Grass 2 Color", &colTwo.r);
		ImGui::ColorEdit3("Grass Color", &colThree.r);
		ImGui::ColorEdit3("Dirt Color", &colFour.r);
		ImGui::ColorEdit3("Water Color", &colFive.r);
		ImGui::ColorEdit3("Water Plane Color", &waterColor.r);
		ImGui::SliderFloat3("Light Orbit Center", &lightOrbitCenter.r, -5.0f, 5.0f);

		ImGui::End();

		ImGui::Render();
		ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwTerminate();
	return 0;
}

void resizeFrameBufferCallback(GLFWwindow* window, int width, int height)
{
	SCREEN_WIDTH = width;
	SCREEN_HEIGHT = height;
	camera.aspectRatio = (float)SCREEN_WIDTH / SCREEN_HEIGHT;
	glViewport(0, 0, width, height);
}

void keyboardCallback(GLFWwindow* window, int keycode, int scancode, int action, int mods)
{
	if (keycode == GLFW_KEY_ESCAPE && action == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, true);
	}
	if (keycode == GLFW_KEY_1 && action == GLFW_PRESS) {
		camera.ortho = false;
	}
	if (keycode == GLFW_KEY_2 && action == GLFW_PRESS) {
		camera.ortho = true;
	}
	if (keycode == GLFW_KEY_SPACE && action == GLFW_PRESS) {
		drawAsPoints = !drawAsPoints;
	} 
	if (keycode == GLFW_KEY_C && action == GLFW_PRESS) {
		cullingEnabled = !cullingEnabled;
		if (cullingEnabled) {
			glEnable(GL_CULL_FACE);
		}
		else {
			glDisable(GL_CULL_FACE);
		}
	}
	//Reset
	if (keycode == GLFW_KEY_R && action == GLFW_PRESS) {
		camera.position = glm::vec3(0,0,5);
		camera.yaw = -90.0f;
		camera.pitch = 0.0f;
		camera.updateVectors();
		firstMouseInput = false;
	}
}

float randomRange(float min, float max)
{
	return min + (max - min) * ((float)rand() / (float)RAND_MAX);
}

void mouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{

	if (abs(yoffset) > 0) {
		camera.fov -= (float)yoffset * camera.zoomSpeed;
		if (camera.fov < 0.0f) {
			camera.fov = 0.0f;
		}
		else if (camera.fov > 180.0f) {
			camera.fov = 180.0f;
		}
	}
}

void mousePosCallback(GLFWwindow* window, double xpos, double ypos)
{
	if (glfwGetInputMode(window, GLFW_CURSOR) != GLFW_CURSOR_DISABLED) {
		return;
	}
	if (!firstMouseInput) {
		prevMouseX = xpos;
		prevMouseY = ypos;
		firstMouseInput = true;
	}
	camera.yaw += (float)(xpos - prevMouseX) * MOUSE_SENSITIVITY;
	camera.pitch -= (float)(ypos - prevMouseY) * MOUSE_SENSITIVITY;

	if (camera.pitch < -89.9f) {
		camera.pitch = -89.9f;
	}
	else if (camera.pitch > 89.9f) {
		camera.pitch = 89.9f;
	}
	prevMouseX = xpos;
	prevMouseY = ypos;

	camera.updateVectors();
}

void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	//Toggle cursor lock
	if (button == 1 && action == GLFW_PRESS) {
		int inputMode = glfwGetInputMode(window, GLFW_CURSOR) == GLFW_CURSOR_DISABLED ? GLFW_CURSOR_NORMAL : GLFW_CURSOR_DISABLED;
		glfwSetInputMode(window, GLFW_CURSOR, inputMode);
		glfwGetCursorPos(window, &prevMouseX, &prevMouseY);
	}
}

float getAxis(GLFWwindow* window, int positiveKey, int negativeKey) {
	float axis = 0.0f;
	if (glfwGetKey(window, positiveKey)) {
		axis++;
	}
	if (glfwGetKey(window, negativeKey)) {
		axis--;
	}
	return axis;
}

void processInput(GLFWwindow* window) {
	float moveAmnt = camera.moveSpeed * deltaTime;
	camera.position += camera.forward * getAxis(window, GLFW_KEY_W, GLFW_KEY_S) * moveAmnt;
	camera.position += camera.right * getAxis(window, GLFW_KEY_D, GLFW_KEY_A) * moveAmnt;
	camera.position += camera.up * getAxis(window, GLFW_KEY_Q, GLFW_KEY_E) * moveAmnt;
}

GLuint loadTexture(const char* filePath)
{
	GLuint texture;
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	stbi_set_flip_vertically_on_load(true);
	int width, height, numComponents;
	unsigned char* textureData = stbi_load(filePath, &width, &height, &numComponents, 0);
	GLint format = numComponents == 3 ? GL_RGB : GL_RGBA;

	if (textureData) {
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, textureData);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else {
		printf("Failed to load texture");
	}
	return texture;
}