#pragma once
#include "EW/Mesh.h"
#include <glm/gtc/type_ptr.hpp>

using namespace glm;

void createPlane(float width, float height, int subdivisions, glm::vec3 color, MeshData& meshData);
void createSphere(float radius, int numSegments, glm::vec3 color, MeshData& meshData);

void createPlane(float width, float height, int subdivisions, glm::vec3 color, MeshData& meshData)
{
	subdivisions++;
	for (float row = 0; row < subdivisions; row++)
	{
		for (float col = 0; col < subdivisions; col++)
		{
			float x = width * (col / subdivisions);
			float z = -height * (row / subdivisions);
			float xT = col / subdivisions, yT = row / subdivisions;
			vec2 texCoords = vec2(xT, yT);
			meshData.vertices.push_back(Vertex(glm::vec3(x, 0, z), color, texCoords, vec3(0, 1, 0)));
		}
	}


	for (float row = 0; row + 1 < subdivisions; row++)
	{
		for (float col = 0; col + 1 < subdivisions; col++)
		{
			float initial = row * subdivisions + col;
			meshData.indices.push_back(initial);
			meshData.indices.push_back(initial + 1);
			meshData.indices.push_back(initial + subdivisions + 1);
			meshData.indices.push_back(initial + subdivisions + 1);
			meshData.indices.push_back(initial + subdivisions);
			meshData.indices.push_back(initial);
		}
	}
}

void createSphere(float radius, int numSegments, glm::vec3 color, MeshData& meshData)
{
	meshData.vertices.clear();
	meshData.indices.clear();

	float topY = radius;
	float bottomY = -radius;

	unsigned int topIndex = 0;
	meshData.vertices.push_back({ glm::vec3(0,topY,0),color,vec2(0,0),glm::vec3(0,1,0) });

	//Angle between segments
	float thetaStep = (2.0f * glm::pi<float>()) / (float)numSegments;
	float phiStep = (glm::pi<float>()) / (float)numSegments;

	for (int i = 1; i < numSegments; i++)
	{
		float phi = phiStep * i;

		//Create row
		for (int j = 0; j <= numSegments; ++j)
		{
			float theta = thetaStep * j;

			float x = radius * sinf(phi) * sinf(theta);
			float y = radius * cosf(phi);
			float z = radius * sinf(phi) * cosf(theta);

			glm::vec3 position = glm::vec3(x, y, z);
			glm::vec3 normal = glm::normalize(glm::vec3(x, y, z));

			meshData.vertices.push_back({ position, color, vec2(x,z),normal });
		}
	}

	meshData.vertices.push_back({ glm::vec3(0,bottomY,0),color,vec2(1,1),glm::vec3(0,-1,0) });
	unsigned int bottomIndex = (unsigned int)meshData.vertices.size() - 1;
	unsigned int ringVertexCount = numSegments + 1;

	//TOP CAP
	for (int i = 0; i < numSegments; ++i) {
		meshData.indices.push_back(topIndex); //top cap center 
		meshData.indices.push_back(i + 1);
		meshData.indices.push_back(i + 2);
	}

	//RINGS
	unsigned int start = 1;

	//Row index
	//-2 to ignore poles
	for (int y = 0; y < numSegments - 2; ++y)
	{
		//Column index
		for (int x = 0; x < numSegments; ++x)
		{
			//Triangle 1
			meshData.indices.push_back(start + y * ringVertexCount + x);
			meshData.indices.push_back(start + (y + 1) * ringVertexCount + x);
			meshData.indices.push_back(start + y * ringVertexCount + x + 1);

			//Triangle 2
			meshData.indices.push_back(start + y * ringVertexCount + x + 1);
			meshData.indices.push_back(start + (y + 1) * ringVertexCount + x);
			meshData.indices.push_back(start + (y + 1) * ringVertexCount + x + 1);
		}
	}

	start = bottomIndex - ringVertexCount;

	//BOTTOM CAP
	for (unsigned int i = 0; i < ringVertexCount; ++i) {
		meshData.indices.push_back(start + i + 1);
		meshData.indices.push_back(start + i);
		meshData.indices.push_back(bottomIndex); //bottom cap center 
	}
}
