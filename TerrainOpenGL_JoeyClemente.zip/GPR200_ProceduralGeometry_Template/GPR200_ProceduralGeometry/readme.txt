Sources:

http://www.aclockworkberry.com/shader-derivative-functions/
Found out the flat shading function for recalculating normals.

https://github.com/SebLague/Procedural-Landmass-Generation
Helped to understand the algorithms involved with heightmapping.